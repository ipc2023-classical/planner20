#pragma once

#define SINGLE_ARG(...) __VA_ARGS__
